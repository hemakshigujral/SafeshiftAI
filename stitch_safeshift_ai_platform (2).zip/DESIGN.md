---
name: SafeShift AI
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#444651'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#757682'
  outline-variant: '#c5c5d3'
  surface-tint: '#4059aa'
  primary: '#00236f'
  on-primary: '#ffffff'
  primary-container: '#1e3a8a'
  on-primary-container: '#90a8ff'
  inverse-primary: '#b6c4ff'
  secondary: '#0051d5'
  on-secondary: '#ffffff'
  secondary-container: '#316bf3'
  on-secondary-container: '#fefcff'
  tertiary: '#002e44'
  on-tertiary: '#ffffff'
  tertiary-container: '#004565'
  on-tertiary-container: '#36b6fb'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b6c4ff'
  on-primary-fixed: '#00164e'
  on-primary-fixed-variant: '#264191'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#c9e6ff'
  tertiary-fixed-dim: '#89ceff'
  on-tertiary-fixed: '#001e2f'
  on-tertiary-fixed-variant: '#004c6e'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.015em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  metric-numeral:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 36px
    letterSpacing: -0.03em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.03em
  code-mono:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system embodies a calm, authoritative, and predictive operational environment tailored for modern workforce oversight and incident prevention. It balances enterprise-grade dependability with proactive AI intelligence. Designed for plant managers, EHS (Environmental Health and Safety) directors, and enterprise operations executives, the interface must evoke trust, immediate situational clarity, and rapid decisive action without inducing sensory fatigue.

The visual style is rooted in a refined **Corporate Modernism** enriched with subtle **Tactile Precision**. The environment relies on clean structural hierarchies, airy atmospheric canvas tones, hyper-crisp card surfaces, and surgical color coding. Proactive AI elements are framed with understated luminous indicators (cyan and cobalt pulses) rather than theatrical decoration, reinforcing utility, actionable insight, and explainable intelligence over pure spectacle.

## Colors

The palette establishes a high-clarity hierarchy using deep structural tones against soft, cool backdrops to minimize glare during prolonged monitoring shifts.

- **Canvas & Surfaces:**
  - Base Application Canvas: `#F8FAFC` (Slate-50) tinted softly with `#F0F9FF` (Sky-50) for operational zones.
  - Surface Containers: Pure `#FFFFFF` for primary cards and widgets, contrasted with hairline borders (`#E2E8F0` at 80% opacity).
  - Muted Insets & Table Headers: `#F1F5F9` (Slate-100).

- **Brand & Structural:**
  - Primary Base: `#1E3A8A` (Deep Royal Navy) used for prominent structural anchors, primary buttons, and key interactive titles.
  - Secondary Accent: `#2563EB` (Cobalt Blue) for active navigation states, primary focus indicators, and prominent links.
  - Tertiary / Intelligence Highlight: `#0EA5E9` (Vibrant Cyan) for AI confidence scoring indicators, predictive trendlines, and proactive recommendations.
  - Deep Neutral: `#0F172A` (Rich Slate/Navy) for primary headings, body typography, and high-impact metric counters.

- **Safety Tier Semantics:**
  - **Low Risk / Safe Operations:** `#10B981` (Emerald) backgrounded with `#ECFDF5` and bordered with `#A7F3D0`.
  - **Medium Risk / Warning:** `#F59E0B` (Amber) backgrounded with `#FFFBEB` and bordered with `#FDE68A`.
  - **High Risk / Critical Emergency:** `#EF4444` (Crimson) backgrounded with `#FEF2F2` and bordered with `#FECACA`.
  - **System Info / Neutral Status:** `#64748B` (Slate) backgrounded with `#F8FAFC`.

## Typography

The typographic hierarchy pairs **Plus Jakarta Sans** for structural brand anchors and executive quantitative display with **Inter** for dense transactional UI, tabular telemetry, and explanatory AI documentation.

- **Plus Jakarta Sans** provides geometric clarity with humanized terminals, lending modernity and executive authority to display stats, panel titles, and section headers.
- **Inter** ensures superior legibility in dense operational logs, time-series shifts, data grids, and status reports, thanks to its tall x-height and neutral grotesque construction.
- Tabular figures (`tnum`) must be enforced across all analytical counters, shift time stamps, and risk indexes to prevent visual shifting during live SSE/WebSocket updates.

## Layout & Spacing

The design system is structured around an adaptive 12-column fluid grid governed by an 8pt modular rhythm (with 4pt sub-steps for compact UI controls).

- **Grid Architecture:**
  - **Desktop (>= 1280px):** 12-column layout, `margin: 2rem`, `gutter: 1.5rem`. Fixed left navigation sidebar (260px expanded, 72px collapsed). Content region leverages high-density split view for operational feeds and map/chart canvas.
  - **Tablet (768px - 1279px):** 8-column layout, `margin: 1.5rem`, `gutter: 1.25rem`. Sidebar folds into an off-canvas drawer or icon rail.
  - **Mobile (< 768px):** 4-column layout, `margin: 1rem`, `gutter: 1rem`. Metrics cards stack into single columns with touch-optimized vertical flows.

- **Rhythm & Alignments:**
  - Standard card interior padding utilizes `space-lg` (24px) for major dashboard summaries and `space-md` (16px) for compact live shift monitors.
  - Vertical spacing between distinct analytical modules maintains a strict `space-xl` (32px) gap to ensure distinct cognitive separation between hazard alerts and standard scheduling matrices.

## Elevation & Depth

The design system prioritizes a **soft tactile elevation model** combined with crisp structural borders, eliminating heavy drop shadows in favor of diffused light-wells and precise border definitions.

- **Flat / Recessed Surface:** `background: #F1F5F9; border: 1px solid #E2E8F0;` Used for search bars, data entry wells, and inactive tab tracks.
- **Card Rest (Level 1):** `background: #FFFFFF; border: 1px solid rgba(226, 232, 240, 0.85); box-shadow: 0 1px 3px 0 rgba(15, 23, 42, 0.03), 0 1px 2px -1px rgba(15, 23, 42, 0.03);` Used for standard operational KPI tiles, shift logs, and safety rosters.
- **Interactive / Hover Surface (Level 2):** `background: #FFFFFF; border: 1px solid #CBD5E1; box-shadow: 0 4px 6px -1px rgba(15, 23, 42, 0.05), 0 2px 4px -2px rgba(15, 23, 42, 0.05); transform: translateY(-1px);` Used for clickable incident rows, actionable suggestions, and card selectors.
- **Overlay & Popover (Level 3):** `background: #FFFFFF; border: 1px solid #CBD5E1; box-shadow: 0 10px 15px -3px rgba(15, 23, 42, 0.08), 0 4px 6px -4px rgba(15, 23, 42, 0.03);` Used for AI diagnostic flyouts, filter dropdowns, and date range pickers.
- **Critical Modal & Alert Drawer (Level 4):** `background: #FFFFFF; border: 1px solid #94A3B8; box-shadow: 0 20px 25px -5px rgba(15, 23, 42, 0.12), 0 8px 10px -6px rgba(15, 23, 42, 0.04);` Used for live high-severity incident dispatch modals.
- **AI Ambient Glow:** AI recommendations use an inner highlight border: `box-shadow: inset 0 0 0 1px rgba(14, 165, 233, 0.3), 0 4px 12px rgba(14, 165, 233, 0.08);`.

## Shapes

The geometric personality balances industrial rigor with human-centered software ergonomics through intentional curvature:

- **Base Radius (`rounded-md` / 8px):** Applied to form fields, nested micro-buttons, dropdown items, tooltips, and table row selections.
- **Container Radius (`rounded-xl` / 16px):** Applied to standard dashboard cards, KPI containers, charts, and slide-over panels.
- **Modal Radius (`rounded-2xl` / 24px):** Reserved for enterprise confirmation modals and system diagnostic overlays.
- **Full Pill (`rounded-full`):** Applied exclusively to status tags, safety badges, risk tier labels, and AI confidence pills to emphasize their state-based nature.

## Components

### Buttons
- **Primary:** Solid `#1E3A8A` background, `#FFFFFF` text, `border-radius: 8px`. Hover: `#2563EB`. Active: `#172554`. Focus-visible ring: 2px offset with `#2563EB`.
- **Secondary:** Surface `#FFFFFF`, border `1px solid #E2E8F0`, text `#0F172A`. Hover: `#F8FAFC` and border `#CBD5E1`.
- **Ghost:** Transparent background, text `#475569`. Hover: `#F1F5F9`, text `#0F172A`.
- **Critical Action:** Background `#EF4444`, text `#FFFFFF`. Hover: `#DC2626`.

### Safety Status Badges
Rendered as full pills (`rounded-full`) with uppercase micro-typography (`label-sm`), featuring a centered 6px pulsating dot indicator:
- **Low Risk:** `#ECFDF5` fill, `#10B981` text, `#A7F3D0` border.
- **Medium Risk:** `#FFFBEB` fill, `#D97706` text, `#FDE68A` border.
- **High Risk:** `#FEF2F2` fill, `#DC2626` text, `#FECACA` border.

### Explainable AI Confidence Tags
Specialized visual indicator communicating predictive accuracy:
- Fill: `#F0F9FF`, text `#0369A1`, border: `1px solid rgba(14, 165, 233, 0.3)`.
- Includes an AI spark icon followed by: "94% Confidence -- Fatigue Predictor". Clicking opens an explainability popover breaking down contributing sensor and shift variables.

### Metric & KPI Cards
- White background (`#FFFFFF`), `rounded-xl` (16px), subtle border (`#E2E8F0` at 80% opacity), level-1 shadow.
- Top row: Metric label (`label-md` in `#64748B`) paired with a contextual category icon in a soft slate circle.
- Middle row: Numerical value (`metric-numeral` in `#0F172A`).
- Bottom row: Trend delta pill (e.g., "+3.2% vs last shift" in Emerald or Crimson) and micro sparkline or secondary comparison caption.

### Input Fields & Controls
- **Inputs:** Height 40px, `rounded-md` (8px), background `#FFFFFF`, border `1px solid #CBD5E1`, text `#0F172A`, placeholder `#94A3B8`. Focus: border `#2563EB`, ring 3px of `rgba(37, 99, 235, 0.15)`.
- **Checkboxes & Radios:** 18px dimensions, border `#94A3B8`, background `#FFFFFF`. Selected: background `#1E3A8A`, icon `#FFFFFF`.

### Incident & Telemetry Data Lists
- Headers formatted in `label-sm`, uppercase `#64748B`, background `#F8FAFC`, border-bottom `1px solid #E2E8F0`.
- Data rows feature alternating subtle hover transitions (`hover:bg-blue-50/40`), baseline height 52px, explicit border-bottom `1px solid #F1F5F9`. Critical incidents trigger an ambient left border-bar in `#EF4444` (width 3px).